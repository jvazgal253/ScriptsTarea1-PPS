#! /bin/bash
if [ $# -ge 2 ];then
echo "Se han introducido correctamente al menos 2 parámetros"
echo "${10}"
else
echo "Escribe al menos dos parámetros."
fi
