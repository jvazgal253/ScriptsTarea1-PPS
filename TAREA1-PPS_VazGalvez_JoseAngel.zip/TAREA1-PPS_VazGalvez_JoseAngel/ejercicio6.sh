#! /bin/bash
IFS='@'
echo "$*"
