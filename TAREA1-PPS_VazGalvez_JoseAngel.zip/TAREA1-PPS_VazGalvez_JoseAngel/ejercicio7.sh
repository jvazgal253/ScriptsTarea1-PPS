#! /bin/bash
IFS='-'
echo "$*"
