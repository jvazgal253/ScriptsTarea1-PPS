#! /bin/bash
if [ -e $2 ]; then
cat "$2"
else 
echo "el archivo no existe"
fi;
echo "exit code: $?"
