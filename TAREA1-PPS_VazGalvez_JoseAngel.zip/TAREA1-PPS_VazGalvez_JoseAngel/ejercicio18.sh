#! /bin/bash
if [ $# -lt 1 ] || [ $# -gt 1 ]; then
echo "Introduce únicamente un parámetro"
else
if [ -e $1 ]; then
if [ -d $1 ]; then
echo "El parámetro es un directorio"
else
echo "El parámetro es un archivo"
fi
else
echo "El parámetro no existe"
fi
fi
