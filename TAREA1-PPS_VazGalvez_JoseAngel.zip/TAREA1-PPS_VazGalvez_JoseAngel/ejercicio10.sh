#! /bin/bash

if [ $# -ge 1 ]; then
 	mkdir "$1"
	cd "$1"
	echo "se ha creado el directorio en: "$PWD

else echo "Introduce un parámetro"
fi

