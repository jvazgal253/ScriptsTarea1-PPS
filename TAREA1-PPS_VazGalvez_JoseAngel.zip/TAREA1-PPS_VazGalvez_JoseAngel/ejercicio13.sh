#! /bin/bash
if [ $# -lt 1 ]; then
echo "No has introducido ningún parámetro."
else
echo "Has introducido $# parámetros"
echo "Los parámetros son: ""$@ "
fi
