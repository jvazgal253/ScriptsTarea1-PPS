# /bin/bash
mkdir "$1"
cp $2 $1

