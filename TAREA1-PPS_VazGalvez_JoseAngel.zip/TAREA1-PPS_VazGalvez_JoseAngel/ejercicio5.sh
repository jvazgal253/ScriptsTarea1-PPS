#! /bin/bash

var1=hola
var2=buenas
var3=tardes
junto=$var1$var2$var3
echo "$junto"
exit;
