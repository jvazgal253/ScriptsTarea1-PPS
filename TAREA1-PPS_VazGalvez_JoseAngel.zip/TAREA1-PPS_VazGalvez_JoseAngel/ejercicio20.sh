# /bin/bash
if [ -e $1 ]; then
echo "El directorio ya existe"
mkdir "$1" 2>/dev/null
cp $2 $1
echo "Archivo copiado satisfactoriamente."
exit 1

else
echo "El directorio no existe"
echo "Creando directorio..."
echo "Directorio creado satisfactoriamente"
mkdir "$1" 2>/dev/null
cp $2 $1
echo "Archivo copiado satisfactoriamente."
fi

