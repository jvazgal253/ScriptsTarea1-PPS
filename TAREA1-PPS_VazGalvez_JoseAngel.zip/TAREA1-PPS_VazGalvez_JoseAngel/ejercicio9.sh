#! /bin/bash
echo "${10}"
