#! /bin/bash
if [ $# -ge 1 ]; then
echo "Se han introducido correctamente los parámetros"
IFS='-'
echo "$*"
else
echo "Introduce al menos un parámetro"
fi
