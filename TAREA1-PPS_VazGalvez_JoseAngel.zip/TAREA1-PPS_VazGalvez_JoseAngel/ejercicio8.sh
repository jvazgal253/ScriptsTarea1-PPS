#! /bin/bash
echo "$basename $0" 
