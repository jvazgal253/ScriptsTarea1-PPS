#! /bin/bash
if [ $# -lt 1 ]; then
echo "No has introducido ningún parámetro."
exit 1
else
echo "Has introducido $# parámetros"
echo "Los parámetros son: ""$@ "
exit 0
fi
