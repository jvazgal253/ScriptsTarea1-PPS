# /bin/bash
if [ -e $1 ]; then
echo "El directorio ya existe"
else
echo "El directorio no existe"
echo "Creando directorio..."
fi
mkdir "$1" 2>/dev/null
cp $2 $1
echo "Archivo copiado satisfactoriamente."
