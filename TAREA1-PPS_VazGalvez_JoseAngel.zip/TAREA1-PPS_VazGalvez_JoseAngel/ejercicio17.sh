# /bin/bash
if [ $# -eq 1 ]; then

	if [ -e $1 ]; then
	echo "El parámetro existe en el sistema"
	else
	echo "El parámetro NO existe en el sistema"
	fi
else
echo "Introduce un parámetro"
fi
